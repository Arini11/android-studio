package net.vidalibarraquer.profe.settings2122;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

public class LecturaOpcions extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lectura_opcions);

        SharedPreferences sharedPreferences =
                PreferenceManager.getDefaultSharedPreferences(this /* Activity context */);
        String name = String.valueOf(sharedPreferences.getBoolean("notificacions",false));

        TextView tvOpcions = (TextView) findViewById(R.id.tvOpcions);

        tvOpcions.setText("Opcions: "+name);
    }
}
