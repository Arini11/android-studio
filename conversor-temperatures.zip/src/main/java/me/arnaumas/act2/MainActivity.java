package me.arnaumas.act2;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import me.arnaumas.act2.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener  {

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;
    private Button btn0,btn1,btn2;
    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn0 = (Button) findViewById(R.id.btnTemperatura);
        btn1 = (Button) findViewById(R.id.btnLongitud);
        btn2 = (Button) findViewById(R.id.btnPes);
        btn0.setOnClickListener(this);
        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnTemperatura:
                intent = new Intent(this,Termperatura.class);
                break;
            case R.id.btnLongitud:
                intent = new Intent(this,Longitud.class);
                break;
            case R.id.btnPes:
                intent = new Intent(this,Pes.class);
                break;
        }
        startActivity(intent);
    }
}