package me.arnaumas.act2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

public class Longitud extends AppCompatActivity implements View.OnClickListener {

    private Button btnHome,btnCalcular;
    private Intent intent;
    private TextView tvResultat, input0;
    private RadioButton rb0,rb1,rb2,rb3,rb02,rb12,rb22,rb32;

    private String resultat = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_longitud);
        btnHome = (Button) findViewById(R.id.btnHome);
        btnCalcular = (Button) findViewById(R.id.btnCalcular);
        tvResultat = (TextView) findViewById(R.id.tvResultat);
        input0 = (TextView) findViewById(R.id.input0);
        rb0 = (RadioButton) findViewById(R.id.rb0);
        rb1 = (RadioButton) findViewById(R.id.rb1);
        rb2 = (RadioButton) findViewById(R.id.rb2);
        rb3 = (RadioButton) findViewById(R.id.rb3);
        rb02 = (RadioButton) findViewById(R.id.rb02);
        rb12 = (RadioButton) findViewById(R.id.rb12);
        rb22 = (RadioButton) findViewById(R.id.rb22);
        rb32 = (RadioButton) findViewById(R.id.rb32);
        btnHome.setOnClickListener(this);
        btnCalcular.setOnClickListener(this);
    }

    public void onClick(View view) {
        if (view.getId() == R.id.btnHome) {
            intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        } else if (view.getId() == R.id.btnCalcular) {
            //Kelvin
            if (rb0.isChecked()) {
                if(rb02.isChecked())
                    resultat = input0.getText().toString();
                else if(rb12.isChecked())
                    resultat = String.valueOf(Double.parseDouble(input0.getText().toString())-273.15) + "";
                else if(rb22.isChecked())
                    resultat = String.valueOf(Double.parseDouble(input0.getText().toString())*1.8-459.67) + " \n";
                else if(rb32.isChecked())
                    resultat = String.valueOf(Double.parseDouble(input0.getText().toString())*1.8) + " ";
                //Celcius
            } else if (rb1.isChecked()) {
                if(rb02.isChecked())
                    resultat = String.valueOf(Double.parseDouble(input0.getText().toString())+273.15) + " \n";
                else if(rb12.isChecked())
                    resultat = input0.getText().toString();
                else if(rb22.isChecked())
                    resultat = String.valueOf(Double.parseDouble(input0.getText().toString())*1.8+32) + " \n";
                else if(rb32.isChecked())
                    resultat = String.valueOf((Double.parseDouble(input0.getText().toString())+273.15)*1.8) + "";
                //Fahrenheit
            } else if (rb2.isChecked()) {
                if(rb02.isChecked())
                    resultat = String.valueOf((Double.parseDouble(input0.getText().toString())+459.67)*1.8) + " \n";
                else if(rb12.isChecked())
                    resultat = String.valueOf((Double.parseDouble(input0.getText().toString())-32)*1.8) + " \n";
                else if(rb22.isChecked())
                    resultat = input0.getText().toString();
                else if(rb32.isChecked())
                    resultat = String.valueOf(Double.parseDouble(input0.getText().toString())+459.67) + " ";
                //Rankine
            } else if (rb3.isChecked()){
                if(rb02.isChecked())
                    resultat = String.valueOf(Double.parseDouble(input0.getText().toString())*1.8) + " \n";
                else if(rb12.isChecked())
                    resultat = String.valueOf((Double.parseDouble(input0.getText().toString())-491.67)*1.8) + " \n";
                else if(rb22.isChecked())
                    resultat = String.valueOf(Double.parseDouble(input0.getText().toString())-459.67) + "";
                else if(rb32.isChecked())
                    resultat = input0.getText().toString();
            }
            tvResultat.setText(resultat);
        }
    }
}