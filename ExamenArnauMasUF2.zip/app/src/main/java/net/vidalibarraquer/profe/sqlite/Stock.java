package net.vidalibarraquer.profe.sqlite;

public class Stock {
    private String key;
    private String country;
    private double latitude;
    private double longitude;
    private String stock_industry;
    private String stock_market;
    private String stock_market_cap;
    private String stock_name;
    private String stock_sector;
    private String stock_symbol;

    public Stock(String country, double latitude, double longitude, String stock_industry, String stock_market, String stock_market_cap, String stock_name, String stock_sector, String stock_symbol) {
        this.country = country;
        this.latitude = latitude;
        this.longitude = longitude;
        this.stock_industry = stock_industry;
        this.stock_market = stock_market;
        this.stock_market_cap = stock_market_cap;
        this.stock_name = stock_name;
        this.stock_sector = stock_sector;
        this.stock_symbol = stock_symbol;
    }

    public Stock() {
        this("",-1,-1,"","","","","","");
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public String getStock_industry() {
        return stock_industry;
    }

    public void setStock_industry(String stock_industry) {
        this.stock_industry = stock_industry;
    }

    public String getStock_market() {
        return stock_market;
    }

    public void setStock_market(String stock_market) {
        this.stock_market = stock_market;
    }

    public String getStock_market_cap() {
        return stock_market_cap;
    }

    public void setStock_market_cap(String stock_market_cap) {
        this.stock_market_cap = stock_market_cap;
    }

    public String getStock_name() {
        return stock_name;
    }

    public void setStock_name(String stock_name) {
        this.stock_name = stock_name;
    }

    public String getStock_sector() {
        return stock_sector;
    }

    public void setStock_sector(String stock_sector) {
        this.stock_sector = stock_sector;
    }

    public String getStock_symbol() {
        return stock_symbol;
    }

    public void setStock_symbol(String stock_symbol) {
        this.stock_symbol = stock_symbol;
    }
}

