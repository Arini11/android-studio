package net.vidalibarraquer.profe.sqlite;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class VeureMapa extends FragmentActivity implements OnMapReadyCallback, GoogleMap.OnMapClickListener, GoogleMap.OnMapLongClickListener {
    private GoogleMap mMap;
    private final int PERMIS_LOCALITZACIO_PRECISA = 1;
    private float lat, lon;
    private String stock;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_veure_mapa);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        String lat = this.getIntent().getStringExtra("lat");
        String lon = this.getIntent().getStringExtra("lon");
        stock = this.getIntent().getStringExtra("stock");
        this.lat = Float.valueOf(lat);
        this.lon = Float.valueOf(lon);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        LatLng tgn = new LatLng(lat, lon);
        afegirMarcador(tgn, stock);

        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        CameraPosition camPos = new CameraPosition.Builder()
                .target(tgn)   // Centrem el mapa a Tarragona
                .zoom(17)       // Establim el zoom en 17
                .bearing(0)     // Establim l'orientació amb el nordest dalt
                .build();

        // Creem un CameraUpdate que crea un moviment cap al marcador
        CameraUpdate camUpdate = CameraUpdateFactory.newCameraPosition(camPos);
        mMap.animateCamera(camUpdate);

        // Escoltem els clicks normals i clicks llargs damunt del mapa
        mMap.setOnMapClickListener(this);
        mMap.setOnMapLongClickListener(this);
        habilitaLocalitzacio();
    }

    // Afegim el marcador al mapa
    private void afegirMarcador(LatLng latitudLongitud, String titol) {
        // Possibles colors: HUE_RED, HUE_AZURE, HUE_BLUE, HUE_CYAN, HUE_GREEN, HUE_MAGENTA, HUE_ORANGEHUE_ROSE, HUE_VIOLET, HUE_YELLOW
        mMap.addMarker(new MarkerOptions().position(latitudLongitud).title(titol)
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));
    }

    // Mètode que demana permisos de localització a l'usuari
    public void habilitaLocalitzacio() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED) {
            mMap.setMyLocationEnabled(true);
        } else {
            // Demanem a l'usuari que ens doni permís per localitzar-se a ell mateix
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMIS_LOCALITZACIO_PRECISA);
        }
    }

    @Override
    public void onMapClick(@NonNull LatLng latLng) {

    }

    @Override
    public void onMapLongClick(@NonNull LatLng latLng) {

    }
}
