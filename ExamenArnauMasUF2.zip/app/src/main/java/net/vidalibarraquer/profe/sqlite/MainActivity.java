package net.vidalibarraquer.profe.sqlite;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, ChildEventListener, ValueEventListener {

private List<Stock> stocks;

public EditText etStock;
public Button btnAfegir;
public RecyclerView viewLlista;
private StocksAdapter stocksAdapter;
private FirebaseDatabase database;
private DatabaseReference dbStocks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Prova firebase
        // Write a message to the database
        database = FirebaseDatabase.getInstance();

        dbStocks = FirebaseDatabase.getInstance().getReference().child("stocks");
        dbStocks.addChildEventListener(this);
        dbStocks.addValueEventListener(this);

        etStock = (EditText) findViewById(R.id.etStock);
        btnAfegir = (Button) findViewById(R.id.btnAfegir);

        btnAfegir.setOnClickListener(this);

        stocks = new ArrayList<Stock>();

        viewLlista = findViewById(R.id.viewLlista);
        // també es pot posar al xml les 3 línies següents
        viewLlista.setHasFixedSize(true);
        viewLlista.setLayoutManager(new LinearLayoutManager(this));
        viewLlista.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));

        stocksAdapter = new StocksAdapter(this, dbStocks, stocks);
        viewLlista.setAdapter(stocksAdapter);
    }

    @Override
    public void onClick(View v) {

        if (v.getId() == R.id.btnAfegir) {
            Stock st = new Stock();
            String stk = etStock.getText().toString();
            st.setKey(stk);
            dbStocks.child(stk).setValue(st);
            // Utilitzo stock dins de l'objecte com a identificador, però no cal guardar-ho a la base de dades, per tant, ho trec.
            // Podria posar els atributs un per un, però és més còmode posar l'objecte sencer, i després treurre l'identificador.
            dbStocks.child(stk).child("stock").setValue("");

        } /*else if(v.getId() == R.id.btnConsultar){
            String matr = etMatricula.getText().toString();
            FirebaseDatabase.getInstance().getReference().child("cotxes").child(matr).child("nom").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {
                    if (!task.isSuccessful()) {
                        Log.e("firebase", "Error getting data", task.getException());
                    }
                    else {
                        Log.d("firebase", String.valueOf(task.getResult().getValue()));
                        Toast.makeText(getApplicationContext(),String.valueOf(task.getResult().getValue()), Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
        */

    }

    @Override
    protected void onResume() {
        super.onResume();
        stocksAdapter.notifyDataSetChanged();
    }

    @Override
    public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

    }

    @Override
    public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

    }

    @Override
    public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

    }

    @Override
    public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

    }

    @Override
    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
        //Toast.makeText(MainActivity.this, "Han canviat dades " + dataSnapshot.getKey() + ": " + dataSnapshot.getValue(), Toast.LENGTH_SHORT).show();
        //Toast.makeText(MainActivity.this, "Hi ha " + dataSnapshot.getChildrenCount() + " stocks a la llista", Toast.LENGTH_SHORT).show();
        // Eliminem tot el contingut per no afegir cada cop que hi ha un canvi
        stocks.removeAll(stocks);

        for (DataSnapshot element : dataSnapshot.getChildren()) {
            Stock st = element.getValue(Stock.class);
            st.setKey(element.getKey());
            stocks.add(st);
        }
        //Log.d("LLISTA", stocks.toString());

        // Per si hi ha canvis, que es refresqui l'adaptador
        stocksAdapter.notifyDataSetChanged();
        viewLlista.setHasFixedSize(true);
        //viewLlista.scrollToPosition(stocks.size() - 1);
    }

    @Override
    public void onCancelled(@NonNull DatabaseError databaseError) {

    }
}
