package net.vidalibarraquer.profe.sqlite;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class VeureStock extends AppCompatActivity implements View.OnClickListener {

    Button btnGuardar, btnDescartar;
    EditText edCountry, edLatitude, edLongitude, edStockIndustry, edStockMarket, edStockMarketCap, edStockName, edStockSector, edStockSymbol;
    ImageButton ibEsborrar, ibMapa;
    String stock;
    TextView tvTitol;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_veure_stock);

        btnGuardar = (Button) findViewById(R.id.btnGuardar);
        btnDescartar = (Button) findViewById(R.id.btnDescartar);
        btnGuardar.setOnClickListener(this);
        btnDescartar.setOnClickListener(this);

        tvTitol = (TextView) findViewById(R.id.tvTitol);

        edCountry = (EditText) findViewById(R.id.edCountry);
        edLatitude = (EditText) findViewById(R.id.edLatitude);
        edLongitude = (EditText) findViewById(R.id.edLongitude);
        edStockIndustry = (EditText) findViewById(R.id.edStockIndustry);
        edStockMarket = (EditText) findViewById(R.id.edStockMarket);
        edStockMarketCap = (EditText) findViewById(R.id.edStockMarketCap);
        edStockName = (EditText) findViewById(R.id.edStockName);
        edStockSector = (EditText) findViewById(R.id.edStockSector);
        edStockSymbol = (EditText) findViewById(R.id.edStockSymbol);
        ibEsborrar = (ImageButton) findViewById(R.id.ibEsborrar);
        ibMapa = (ImageButton) findViewById(R.id.ibMapa);

        edCountry.setOnClickListener(this);
        edLatitude.setOnClickListener(this);
        edLongitude.setOnClickListener(this);
        edStockIndustry.setOnClickListener(this);
        edStockMarket.setOnClickListener(this);
        edStockMarketCap.setOnClickListener(this);
        edStockName.setOnClickListener(this);
        edStockSector.setOnClickListener(this);
        edStockSymbol.setOnClickListener(this);
        ibEsborrar.setOnClickListener(this);
        ibMapa.setOnClickListener(this);

        stock = this.getIntent().getStringExtra("stock");

        tvTitol.setText(stock);

        FirebaseDatabase.getInstance().getReference().child("stocks").child(stock).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()) {
                    try {
                        throw new Exception("ERROR");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    Stock st = task.getResult().getValue(Stock.class);

                    edCountry.setText(st.getCountry());
                    edLatitude.setText(String.valueOf(st.getLatitude()));
                    edLongitude.setText(String.valueOf(st.getLongitude()));
                    edStockIndustry.setText(st.getStock_industry());
                    edStockMarket.setText(st.getStock_market());
                    edStockMarketCap.setText(st.getStock_market_cap());
                    edStockName.setText(st.getStock_name());
                    edStockSector.setText(st.getStock_sector());
                    edStockSymbol.setText(st.getStock_symbol());
                }
            }
        });

    }


    @Override
    public void onClick(View v) {
        DatabaseReference dbStocks = FirebaseDatabase.getInstance().getReference().child("stocks");
        if (v.getId() == R.id.btnGuardar) {
            String country, stockIndustry, stockMarket, stockMarketCap, stockName, stockSector, stockSymbol;
            double latitude, longitude;

            country = edCountry.getText().toString();
            latitude = Double.valueOf(edLatitude.getText().toString());
            longitude = Double.valueOf(edLongitude.getText().toString());
            stockIndustry = edStockIndustry.getText().toString();
            stockMarket = edStockMarket.getText().toString();
            stockMarketCap = edStockMarketCap.getText().toString();
            stockName = edStockName.getText().toString();
            stockSector = edStockSector.getText().toString();
            stockSymbol = edStockSymbol.getText().toString();

            if(!edCountry.getText().toString().equals("-")){
                country = edCountry.getText().toString();
            }
            if(!edLatitude.getText().toString().equals("-1")){
                latitude = Double.valueOf(edLatitude.getText().toString());
            }
            if(!edLongitude.getText().toString().equals("-1")){
                longitude = Double.valueOf(edLongitude.getText().toString());
            }
            if(!edStockIndustry.getText().toString().equals("-")){
                stockIndustry = edStockIndustry.getText().toString();
            }
            if(!edStockMarket.getText().toString().equals("-")){
                stockMarket = edStockMarket.getText().toString();
            }
            if(!edStockMarketCap.getText().toString().equals("-")){
                stockMarketCap = edStockMarketCap.getText().toString();
            }
            if(!edStockName.getText().toString().equals("-")){
                stockName = edStockName.getText().toString();
            }
            if(!edStockSector.getText().toString().equals("-")){
                stockSector = edStockSector.getText().toString();
            }
            if(!edStockSymbol.getText().toString().equals("-")){
                stockSymbol = edStockSymbol.getText().toString();
            }


            Stock st = new Stock(country, latitude, longitude, stockIndustry, stockMarket, stockMarketCap, stockName, stockSector, stockSymbol);
            dbStocks.child(stock).setValue(st);
        } else if (v.getId() == R.id.btnDescartar){
            this.finish();
        } else if(v.getId() == R.id.ibEsborrar){
            dbStocks.child(stock).setValue(null);
            this.finish();
        } else if(v.getId() == R.id.ibMapa){
            Intent intent = new Intent(v.getContext(), VeureMapa.class);
            intent.putExtra("stock", tvTitol.getText().toString());
            intent.putExtra("lat", edLatitude.getText().toString());
            intent.putExtra("lon", edLongitude.getText().toString());
            v.getContext().startActivity(intent);
        }

    }
}