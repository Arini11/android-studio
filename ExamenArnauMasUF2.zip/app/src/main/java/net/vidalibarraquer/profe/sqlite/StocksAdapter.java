package net.vidalibarraquer.profe.sqlite;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;

import java.util.List;

public class StocksAdapter extends RecyclerView.Adapter<StocksAdapter.ViewHolder> {
    private View mView;
    public  List<Stock> llistaStocks;
    private Context context;
    private DatabaseReference databaseReference;

    public StocksAdapter(Context context, DatabaseReference databaseReference, List<Stock> llistaStocks) {
        this.context = context;
        this.databaseReference = databaseReference;
        this.llistaStocks = llistaStocks;
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView txtElement;
        public RecyclerView viewLlista;

        public ViewHolder(View v) {
            super(v);

            viewLlista = v.findViewById(R.id.viewLlista);

            v.setOnClickListener(this); // Per escoltar els clicks (no oblidar!)
            txtElement = itemView.findViewById(R.id.textElement);
        }

        // Mètode a implementar de la interfície View.OnClickListener
        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            Intent intent = new Intent(v.getContext(), VeureStock.class);
            intent.putExtra("stock", llistaStocks.get(position).getKey());
            v.getContext().startActivity(intent);
        }

        public TextView getTxtElement() {
            return txtElement;
        }

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_holder, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.getTxtElement().setText(llistaStocks.get(position).getKey());
    }

    @Override
    public int getItemCount() {
        return llistaStocks.size();
    }

}