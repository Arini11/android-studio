package me.arnaumas;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import me.arnaumas.R;

import java.util.ArrayList;
import java.util.List;

public class MostraEquip extends AppCompatActivity {
    List<Equip> elements;
    ImageView im1;
    TextView tv1, tv2, tv3;
    private final Equip equip = new Equip();
    String tipusURL;

    public MostraEquip(){}
    public MostraEquip(List<Equip> elements) {
        this.elements = elements;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostra_personatge);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        im1 = (ImageView) findViewById(R.id.imageView);
        tv1 = (TextView) findViewById(R.id.textView);
        tv2 = (TextView) findViewById(R.id.textView2);
        tv3 = (TextView) findViewById(R.id.textView3);

        elements = CarregarDades.getElements();

        //Recuperem l'extra de les dades anteriors
        Intent intent = getIntent();
        final String imatge = intent.getStringExtra("code");
        final String nom = intent.getStringExtra("name");
        final String clau = intent.getStringExtra("key");

        for(Equip e : elements){
            if(e.getCode().equalsIgnoreCase(imatge)){
                equip.setCode(imatge);
                equip.setName(nom);
                equip.setKey(clau);
                equip.setLliga(e.getLliga());
                break;
            }
        }

        SharedPreferences sharedPreferences =
                PreferenceManager.getDefaultSharedPreferences(this /* Activity context */);
        String urllink = String.valueOf(sharedPreferences.getBoolean("urllink",false));

        if(urllink.equals("false"))
            tipusURL = "futbol";
        else
            tipusURL = "soccer";

        String url = "https://www.vidalibarraquer.net/android/"+tipusURL+"/"+equip.getLliga()+"/"+imatge.toLowerCase()+".json";
        System.out.println(url);
        JsonObjectRequest request = new JsonObjectRequest(url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Obtenim l'array que té per nom data
                        JSONArray jsonArray = null;
                        try {
                            jsonArray = response.getJSONArray("data");
                            equip.setFounded(jsonArray.getJSONObject(0).getString("founded"));
                            equip.setGround(jsonArray.getJSONObject(0).getString("ground"));
                        } catch (JSONException jsonException) {
                            jsonException.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Toast.makeText("Error en obtenir dades", Toast.LENGTH_SHORT).show();
                    }
                });
        RequestQueue requestQueue = Volley.newRequestQueue(MostraEquip.this);
        requestQueue.add(request);

        //Creem URL
        String URL = "https://www.vidalibarraquer.net/android/"+tipusURL+"/"+equip.getLliga()+"/"+imatge.toLowerCase()
                +".png";
        ImageRequest imageRequest = new ImageRequest(URL, new Response.Listener<Bitmap>() {
            @Override
            public void onResponse(final Bitmap response) {
                im1.setImageBitmap(response);
                tv1.setText(getString(R.string.nom) + nom);
                tv2.setText("Fundat: " + equip.getFounded());
                tv3.setText("Estadi: " + equip.getGround());
            }
        }, 0, 0, ImageView.ScaleType.CENTER_INSIDE, null, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MostraEquip.this, error.toString(), Toast.LENGTH_LONG).show();
            }
        });

        RequestQueue requestQueue2 = Volley.newRequestQueue(MostraEquip.this);
        requestQueue2.add(imageRequest);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
