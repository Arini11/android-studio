package me.arnaumas;

public class Equip {
    private String key;
    private String name;
    private String code;
    private String lliga;

    public Equip() {
    }

    public String getFounded() {
        return founded;
    }

    public void setFounded(String founded) {
        this.founded = founded;
    }

    public String getGround() {
        return ground;
    }

    public void setGround(String ground) {
        this.ground = ground;
    }

    private String founded;
    private String ground;

    public Equip(String key, String name, String code, String lliga) {
        this.key = key;
        this.name = name;
        this.code = code;
        this.lliga = lliga;
        //this.founded = founded;
        //this.ground = ground;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getLliga() { return lliga; }

    public void setLliga(String lliga) { this.lliga = lliga; }

}
