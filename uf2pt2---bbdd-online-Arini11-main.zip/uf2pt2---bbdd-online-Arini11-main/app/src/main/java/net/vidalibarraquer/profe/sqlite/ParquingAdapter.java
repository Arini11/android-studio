package net.vidalibarraquer.profe.sqlite;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;

import java.util.List;

public class ParquingAdapter extends RecyclerView.Adapter<ParquingAdapter.ViewHolder> {
    private View mView;
    public  List<Vehicle> llistaVehicles;
    private Context context;
    private DatabaseReference databaseReference;

    public ParquingAdapter(Context context, DatabaseReference databaseReference, List<Vehicle> llistaVehicles) {
        this.context = context;
        this.databaseReference = databaseReference;
        this.llistaVehicles = llistaVehicles;
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public EditText tvMatricula, tvMarca, tvModel, tvNom, tvCognom, tvTelefon;
        private TextView txtElement;
        public RecyclerView viewLlista;

        public ViewHolder(View v) {
            super(v);
            tvMatricula = (EditText) v.findViewById(R.id.tvMatricula);
            tvMarca = (EditText) v.findViewById(R.id.tvMarca);
            tvModel = (EditText) v.findViewById(R.id.tvModel);
            tvNom = (EditText) v.findViewById(R.id.tvNom);
            tvCognom = (EditText) v.findViewById(R.id.tvCognom);
            tvTelefon = (EditText) v.findViewById(R.id.tvTelefon);

            viewLlista = v.findViewById(R.id.viewLlista);

            v.setOnClickListener(this); // Per escoltar els clicks (no oblidar!)
            txtElement = itemView.findViewById(R.id.textElement);
        }

        // Mètode a implementar de la interfície View.OnClickListener
        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            Intent intent = new Intent(v.getContext(), VeureVehicle.class);
            intent.putExtra("matricula", llistaVehicles.get(position).getMatricula());
            v.getContext().startActivity(intent);
        }

        public TextView getTxtElement() {
            return txtElement;
        }

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_holder, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.getTxtElement().setText(llistaVehicles.get(position).getMatricula());
    }

    @Override
    public int getItemCount() {
        return llistaVehicles.size();
    }

}