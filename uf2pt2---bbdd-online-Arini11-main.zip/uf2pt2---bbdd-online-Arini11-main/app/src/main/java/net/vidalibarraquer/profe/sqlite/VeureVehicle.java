package net.vidalibarraquer.profe.sqlite;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class VeureVehicle extends AppCompatActivity implements View.OnClickListener {

    Button btnGuardar, btnDescartar;
    EditText tvMatricula, tvMarca, tvModel, tvNom, tvCognom, tvTelefon;
    ImageButton ibEsborrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_veure_vehicle);

        btnGuardar = (Button) findViewById(R.id.btnGuardar);
        btnDescartar = (Button) findViewById(R.id.btnDescartar);
        btnGuardar.setOnClickListener(this);
        btnDescartar.setOnClickListener(this);

        tvMatricula = (EditText) findViewById(R.id.tvMatricula);
        tvMarca = (EditText) findViewById(R.id.tvMarca);
        tvModel = (EditText) findViewById(R.id.tvModel);
        tvNom = (EditText) findViewById(R.id.tvNom);
        tvCognom = (EditText) findViewById(R.id.tvCognom);
        tvTelefon = (EditText) findViewById(R.id.tvTelefon);
        ibEsborrar = (ImageButton) findViewById(R.id.ibEsborrar);

        tvMatricula.setOnClickListener(this);
        tvMarca.setOnClickListener(this);
        tvModel.setOnClickListener(this);
        tvNom.setOnClickListener(this);
        tvCognom.setOnClickListener(this);
        tvTelefon.setOnClickListener(this);
        ibEsborrar.setOnClickListener(this);

        String matr = this.getIntent().getStringExtra("matricula");

        FirebaseDatabase.getInstance().getReference().child("cotxes").child(matr).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()) {
                    try {
                        throw new Exception("ERROR");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    Vehicle vh = task.getResult().getValue(Vehicle.class);

                    tvMatricula.setText(vh.getMatricula());
                    tvMarca.setText(vh.getMarca());
                    tvModel.setText(vh.getModel());
                    tvNom.setText(vh.getNom());
                    tvCognom.setText(vh.getCognoms());
                    tvTelefon.setText(vh.getTelefon());
                }
            }
        });

    }


    @Override
    public void onClick(View v) {
        DatabaseReference dbCotxes = FirebaseDatabase.getInstance().getReference().child("cotxes");
        if (v.getId() == R.id.btnGuardar) {
            String matricula, marca, model, nom, cognom, telefon;

            matricula = tvMatricula.getText().toString();
            marca = tvMarca.getText().toString();
            model = tvModel.getText().toString();
            nom = tvNom.getText().toString();
            cognom = tvCognom.getText().toString();
            telefon = tvTelefon.getText().toString();

            if(!tvMatricula.getText().toString().equals("-")){
                matricula = tvMatricula.getText().toString();
            }
            if(!tvMarca.getText().toString().equals("-")){
                marca = tvMarca.getText().toString();
            }
            if(!tvModel.getText().toString().equals("-")){
                model = tvModel.getText().toString();
            }
            if(!tvNom.getText().toString().equals("-")){
                nom = tvNom.getText().toString();
            }
            if(!tvCognom.getText().toString().equals("-")){
                cognom = tvCognom.getText().toString();
            }
            if(!tvTelefon.getText().toString().equals("-")){
                telefon = tvTelefon.getText().toString();
            }


            Vehicle vh = new Vehicle(matricula, nom, cognom, telefon, marca, model);
            dbCotxes.child(matricula).setValue(vh);
        } else if (v.getId() == R.id.btnDescartar){
            this.finish();
        } else if(v.getId() == R.id.ibEsborrar){
            String matricula = tvMatricula.getText().toString();
            dbCotxes.child(matricula).setValue(null);
            this.finish();
        }

    }
}