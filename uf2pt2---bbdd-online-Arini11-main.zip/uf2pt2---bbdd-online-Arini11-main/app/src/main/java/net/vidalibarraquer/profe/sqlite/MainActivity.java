package net.vidalibarraquer.profe.sqlite;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, ChildEventListener, ValueEventListener {

private List<Vehicle> vehicles;

public EditText etMat, etMatricula;
public Button btnAfegir, btnConsultar;
public RecyclerView viewLlista;
private ParquingAdapter parquingAdapter;
private FirebaseDatabase database;
private DatabaseReference dbCotxes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Prova firebase
        // Write a message to the database
        database = FirebaseDatabase.getInstance();

        dbCotxes = FirebaseDatabase.getInstance().getReference().child("cotxes");
        dbCotxes.addChildEventListener(this);
        dbCotxes.addValueEventListener(this);

        etMat = (EditText) findViewById(R.id.etMat);
        btnAfegir = (Button) findViewById(R.id.btnAfegir);
        etMatricula = (EditText) findViewById(R.id.etMatricula);
        btnConsultar = (Button) findViewById(R.id.btnConsultar);

        btnAfegir.setOnClickListener(this);
        btnConsultar.setOnClickListener(this);

        vehicles = new ArrayList<Vehicle>();

        parquingAdapter = new ParquingAdapter(this, dbCotxes, vehicles);
        viewLlista = findViewById(R.id.viewLlista);
        // també es pot posar al xml les 3 línies següents
        viewLlista.setHasFixedSize(true);
        viewLlista.setLayoutManager(new LinearLayoutManager(this));
        viewLlista.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));

        viewLlista.setAdapter(parquingAdapter);
    }

    @Override
    public void onClick(View v) {

        if (v.getId() == R.id.btnAfegir) {
            Vehicle vh = new Vehicle();
            String matr = etMat.getText().toString();
            vh.setMatricula(matr);
            //if(!existeixMatricula(matr)){
                dbCotxes.child(matr).setValue(vh);
            //} else{
                //Toast.makeText(getApplicationContext(),""+matr+" ja existeix!", Toast.LENGTH_LONG).show();
            //}

        } else if(v.getId() == R.id.btnConsultar){
            String matr = etMatricula.getText().toString();
            FirebaseDatabase.getInstance().getReference().child("cotxes").child(matr).child("nom").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {
                    if (!task.isSuccessful()) {
                        Log.e("firebase", "Error getting data", task.getException());
                    }
                    else {
                        Log.d("firebase", String.valueOf(task.getResult().getValue()));
                        Toast.makeText(getApplicationContext(),String.valueOf(task.getResult().getValue()), Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

    }

    private boolean existeixMatricula(String matricula) {
        try {
            FirebaseDatabase.getInstance().getReference().child("cotxes").child(matricula).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {
                    if (!task.isSuccessful()) {
                        Log.d("matricula", "No l'ha trobat");
                        try {
                            throw new Exception("ERROR");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    } else {
                        Log.d("matricula", "L'ha trobat");
                    }
                }
            });
        } catch(Throwable t){
            return false;
        }
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        parquingAdapter.notifyDataSetChanged();
    }

    @Override
    public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

    }

    @Override
    public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

    }

    @Override
    public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

    }

    @Override
    public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

    }

    @Override
    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
        Toast.makeText(MainActivity.this, "Han canviat dades " + dataSnapshot.getKey() + ": " + dataSnapshot.getValue(), Toast.LENGTH_SHORT).show();
        Toast.makeText(MainActivity.this, "Hi ha " + dataSnapshot.getChildrenCount() + " vehicles a la llista", Toast.LENGTH_SHORT).show();
        // Eliminem tot el contingut per no afegir cada cop que hi ha un canvi
        vehicles.removeAll(vehicles);

        for (DataSnapshot element : dataSnapshot.getChildren()) {
            Vehicle vh = element.getValue(Vehicle.class);
            vehicles.add(vh);
        }
        Log.d("LLISTA", vehicles.toString());

        // Per si hi ha canvis, que es refresqui l'adaptador
        parquingAdapter.notifyDataSetChanged();
        viewLlista.scrollToPosition(vehicles.size() - 1);
    }

    @Override
    public void onCancelled(@NonNull DatabaseError databaseError) {

    }
}
