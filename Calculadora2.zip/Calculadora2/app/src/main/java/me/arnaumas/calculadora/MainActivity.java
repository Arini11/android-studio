package me.arnaumas.calculadora;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText txtInput;
    Button btnSumar,btnRestar,btnMultiplicar,btnDividir,btnResultat;
    TextView tvRes;

    double resultat,n0,n1;

    // 0-> Suma 1->Resta 2->Multiplicació 3->Divisió
    int estat;

    DecimalFormat df;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtInput = (EditText) findViewById(R.id.num0);
        tvRes = (TextView) findViewById(R.id.tvResultat);
        btnSumar = findViewById(R.id.btnSumar);
        btnRestar = findViewById(R.id.btnRestar);
        btnMultiplicar = findViewById(R.id.btnMultiplicar);
        btnDividir = findViewById(R.id.btnDividir);
        btnResultat = findViewById(R.id.btnResultat);
        btnSumar.setOnClickListener(this);
        btnRestar.setOnClickListener(this);
        btnMultiplicar.setOnClickListener(this);
        btnDividir.setOnClickListener(this);
        btnResultat.setOnClickListener(this);
        df = new DecimalFormat("0.00");
    }

    @Override
    public void onClick(View view) {
        if (txtInput.getText().toString().isEmpty()) { txtInput.setText("0"); }
        if(view.getId() != R.id.btnResultat) n0 = Double.parseDouble(txtInput.getText().toString());

        switch (view.getId()) {
            case R.id.btnSumar:
                estat = 0;
                break;
            case R.id.btnRestar:
                estat = 1;
                break;
            case R.id.btnMultiplicar:
                estat = 2;
                break;
            case R.id.btnDividir:
                estat = 3;
                break;
            case R.id.btnResultat:
                n1 = Double.parseDouble(txtInput.getText().toString());
                switch (estat){
                    case 0:
                        resultat = n0 + n1;
                        break;
                    case 1:
                        resultat = n0 - n1;
                        break;
                    case 2:
                        resultat = n0 * n1;
                        break;
                    case 3:
                        if(n1 == 0) {resultat = 0;}
                        else { resultat = n0 / n1;}
                        break;
                }
                tvRes.setText(String.valueOf(df.format(resultat)));
                estat = 99;
                break;
        }
        txtInput.setText("");
    }
}