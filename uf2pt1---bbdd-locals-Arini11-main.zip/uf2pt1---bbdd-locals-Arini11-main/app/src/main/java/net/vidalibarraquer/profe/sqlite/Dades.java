package net.vidalibarraquer.profe.sqlite;

import java.util.List;

public class Dades {

    private static Dades instance = new Dades();
    public List<Vehicle> vehicles;

    public static Dades getInstance() {
        if(instance == null) {
            instance = new Dades();
        }
        return instance;
    }
    private Dades() { }

}

