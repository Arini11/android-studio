package net.vidalibarraquer.profe.sqlite;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class VeureVehicle extends AppCompatActivity implements View.OnClickListener {

    Button btnGuardar, btnDescartar;
    EditText tvMatricula, tvMarca, tvModel, tvNom, tvCognom, tvTelefon;

    ManegadorDades db = new ManegadorDades(VeureVehicle.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_veure_vehicle);

        btnGuardar = (Button) findViewById(R.id.btnGuardar);
        btnDescartar = (Button) findViewById(R.id.btnDescartar);
        btnGuardar.setOnClickListener(this);
        btnDescartar.setOnClickListener(this);

        tvMatricula = (EditText) findViewById(R.id.tvMatricula);
        tvMarca = (EditText) findViewById(R.id.tvMarca);
        tvModel = (EditText) findViewById(R.id.tvModel);
        tvNom = (EditText) findViewById(R.id.tvNom);
        tvCognom = (EditText) findViewById(R.id.tvCognom);
        tvTelefon = (EditText) findViewById(R.id.tvTelefon);

        tvMatricula.setOnClickListener(this);
        tvMarca.setOnClickListener(this);
        tvModel.setOnClickListener(this);
        tvNom.setOnClickListener(this);
        tvCognom.setOnClickListener(this);
        tvTelefon.setOnClickListener(this);

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();

        if(extras.getString("MATRICULA").equals("-"))
            tvMatricula.setText("matrícula");
        else
            tvMatricula.setText(extras.getString("MATRICULA"));

        tvMarca.setText(extras.getString("MARCA"));
        tvModel.setText(extras.getString("MODEL"));
        tvNom.setText(extras.getString("NOM"));
        tvCognom.setText(extras.getString("COGNOMS"));
        tvTelefon.setText(extras.getString("TELEFON"));
    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnGuardar) {
            String matricula, marca, model, nom, cognom, telefon;

            matricula = tvMatricula.getText().toString();
            marca = tvMarca.getText().toString();
            model = tvModel.getText().toString();
            nom = tvNom.getText().toString();
            cognom = tvCognom.getText().toString();
            telefon = tvTelefon.getText().toString();
/*
            if(!tvMatricula.getText().toString().equals("")){
                matricula = tvMatricula.getText().toString();
                System.out.println(matricula);
            }
            if(!tvMarca.getText().toString().equals("")){
                marca = tvMarca.getText().toString();
                System.out.println("marca ->"+marca);
            }
            if(!tvModel.getText().toString().equals("")){
                model = tvModel.getText().toString();
            }
            if(!tvNom.getText().toString().equals("")){
                nom = tvNom.getText().toString();
            }
            if(!tvCognom.getText().toString().equals("")){
                cognom = tvCognom.getText().toString();
            }
            if(!tvTelefon.getText().toString().equals("")){
                telefon = tvTelefon.getText().toString();
            }
            */

            // Fer update amb les dades modificades
            try {
                Vehicle vh = new Vehicle(matricula, nom, cognom, telefon, marca, model);
                db.updateGame(vh);
                Dades.getInstance().vehicles = db.getAllVideoGames();
                System.out.println(Dades.getInstance().vehicles.toString());
                Toast.makeText(this,"Guardat!", Toast.LENGTH_SHORT);
            }catch (Exception e){
                Toast.makeText(this,"Error en actualitzar el Vehicle!", Toast.LENGTH_SHORT);
            }

            //this.finish();
        } else if (v.getId() == R.id.btnDescartar){
            this.finish();
        }

    }
}