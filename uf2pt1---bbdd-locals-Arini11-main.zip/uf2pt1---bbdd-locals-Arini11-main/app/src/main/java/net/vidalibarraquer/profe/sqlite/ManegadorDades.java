package net.vidalibarraquer.profe.sqlite;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.sax.TextElementListener;

import java.util.ArrayList;
import java.util.List;


public class ManegadorDades extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    //NOM DE LA BASE DE DADES
    private static final String DATABASE_NAME = "bbddParking";
    // NOM DE LA TAULA
    private static final String TABLE_PARKING = "parking";
    //CAMPS DE LA BASE DE DADES
    //Nom, Cognoms, Telèfon, Marca Vehicle, Model Vehicle i Matrícula
    private static final String KEY_MATRICULA = "matricula";
    private static final String KEY_NOM = "nom";
    private static final String KEY_COGNOMS = "cognoms";
    private static final String KEY_TELEFON = "telefon";
    private static final String KEY_MARCA = "marca";
    private static final String KEY_MODEL = "model";

    public ManegadorDades(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String Create_Table = "CREATE TABLE " + TABLE_PARKING + "("
                + KEY_MATRICULA + " TEXT,"
                + KEY_NOM + " TEXT, "
                + KEY_COGNOMS + " TEXT, "
                + KEY_TELEFON + " TEXT, "
                + KEY_MARCA + " TEXT, "
                + KEY_MODEL + " TEXT, "
                + "PRIMARY KEY(" + KEY_MATRICULA + ")"
                + ")";
        db.execSQL(Create_Table);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        // Drop si la taula ja existeix
        db.execSQL("DROP TABLE  IF EXISTS " + TABLE_PARKING);
        // Crear la taula de nou
        onCreate(db);
    }

    // Afegir un registre nou
    public boolean addVehicle(Vehicle vh) {
        //
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues valors = new ContentValues();
        valors.put(KEY_MATRICULA, vh.getMatricula());
        valors.put(KEY_NOM, vh.getNom());
        valors.put(KEY_COGNOMS, vh.getCognoms());
        valors.put(KEY_TELEFON, vh.getTelefon());
        valors.put(KEY_MARCA, vh.getMarca());
        valors.put(KEY_MODEL, vh.getModel());

        // Insertar el registre
        long res = db.insert(TABLE_PARKING,null,valors);
        // Tancar  conexio base de dades
        db.close();

        if(res == -1) return false;
        else return true;
    }

    //Query que retorna tots els  registres de la taula
    public List<Vehicle> getAllVideoGames(){
        List<Vehicle> vg = new ArrayList<Vehicle>();
        // Query de tots els registres de la taula
        String selectTots ="SELECT * FROM "+ TABLE_PARKING;
        // Executem la query
        // QUAN NOMÉS RETORNA UN REGISTRE ÉS getReadableDatabase SI RETORNA MÉS D'UN REGISTRE, SERIA getWritableDatabase()
        SQLiteDatabase db = this.getWritableDatabase();
        // Guarda els resultats en un Cursor
        Cursor cursor = db.rawQuery(selectTots, null);
        // Desplaçament pel cursor

        if (cursor.moveToFirst()) {
            do{
                // Creem l'objecte
                Vehicle vh = new Vehicle();
                // Creem els atributs de la classe
                vh.setMatricula(cursor.getString(0));
                vh.setNom(cursor.getString(1));
                vh.setCognoms(cursor.getString(2));
                vh.setTelefon(cursor.getString(3));
                vh.setMarca(cursor.getString(4));
                vh.setModel(cursor.getString(5));
                // Afegim a la llista l'objecte
                vg.add(vh);

            } while (cursor.moveToNext());
        }

        return vg;

    }

    // Query que retorna un sol registre de la taula
    public String consultarMatricula(String matricula){
        SQLiteDatabase db =this.getReadableDatabase();
        // Creem un cursor per desplaçar-se pels registres per localitzar l'element en concret
        Cursor cursor = db.query(TABLE_PARKING, new String[]{KEY_MATRICULA, KEY_NOM, KEY_COGNOMS, KEY_TELEFON, KEY_MARCA, KEY_MODEL},
                KEY_MATRICULA+ "= ?", new String[]{matricula}, null, null, null, null);

        if(cursor == null) {
            System.out.println("cursor no funciona");
            return "";
        }
        cursor.moveToFirst();
        return cursor.getString(1);
    }

    // Query que retorna un sol registre de la taula
    public Vehicle vGame(String matricula){
        SQLiteDatabase db =this.getReadableDatabase();
        // Creem un cursor per desplaçar-se pels registres per localitzar l'element en concret
        Cursor cursor = db.query(TABLE_PARKING, new String[]{KEY_MATRICULA, KEY_NOM, KEY_COGNOMS, KEY_TELEFON, KEY_MARCA, KEY_MODEL},
                 KEY_MATRICULA+ "= ?", new String[]{matricula}, null, null, null, null);

        if(cursor != null) {
            cursor.moveToFirst();
        }

        Vehicle vg = new Vehicle(cursor.getString(0),
            cursor.getString(1),
            cursor.getString(2),
            cursor.getString(3),
            cursor.getString(4),
            cursor.getString(5));

        return vg;
    }

    //Query per actualitzar un registre de la Taula
    public int updateGame(Vehicle vh){
        SQLiteDatabase db =this.getWritableDatabase();

        ContentValues valors = new ContentValues();
        valors.put(KEY_MATRICULA, vh.getMatricula());
        valors.put(KEY_NOM, vh.getNom());
        valors.put(KEY_COGNOMS, vh.getCognoms());
        valors.put(KEY_TELEFON, vh.getTelefon());
        valors.put(KEY_MARCA, vh.getMarca());
        valors.put(KEY_MODEL, vh.getModel());

        //Actualitzem a la Base de dades
        return db.update(TABLE_PARKING, valors, KEY_MATRICULA+"=?",
                new String[]{vh.getMatricula()});

    }

    //Query per esborrar un registre de la Taula
    public void deleteVehicle(Vehicle vh){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_PARKING, KEY_MATRICULA+"= ?",
                new String[]{vh.getMatricula()});
        db.close();
    }
}

