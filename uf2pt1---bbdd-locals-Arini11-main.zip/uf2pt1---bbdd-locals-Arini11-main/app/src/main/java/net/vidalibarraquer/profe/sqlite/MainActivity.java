package net.vidalibarraquer.profe.sqlite;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

private List<Vehicle> vehicles;

public EditText etMat, etMatricula;
public Button btnAfegir, btnConsultar;
public RecyclerView viewLlista;

ManegadorDades db = new ManegadorDades(MainActivity.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Guardo la els vehicles a la llista vehicles de Dades,
        // que és un singleton, per facilitar-ne l'accés al llarg del programa
        Dades.getInstance().vehicles = db.getAllVideoGames();
        vehicles = Dades.getInstance().vehicles;
        //vehicles = db.getAllVideoGames();
        MyRecyclerViewAdapter adapter = new MyRecyclerViewAdapter();
        viewLlista = (RecyclerView) findViewById(R.id.viewLlista);
        viewLlista.setAdapter(adapter);

        etMat = (EditText) findViewById(R.id.etMat);
        btnAfegir = (Button) findViewById(R.id.btnAfegir);
        etMatricula = (EditText) findViewById(R.id.etMatricula);
        btnConsultar = (Button) findViewById(R.id.btnConsultar);
        btnAfegir.setOnClickListener(this);
        btnConsultar.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        if (v.getId() == R.id.btnAfegir) {
            Vehicle vg = new Vehicle();
            vg.setMatricula(etMat.getText().toString());
            if(db.addVehicle(vg)) {
                etMat.setText("");
                vehicles.add(vg);
                //Notificar que s'ha afegit un element
                viewLlista.getAdapter().notifyItemInserted(vehicles.size() - 1);
            }
        } else if(v.getId() == R.id.btnConsultar){
            ManegadorDades db = new ManegadorDades(v.getContext());
            String matr = etMatricula.getText().toString();
            String res = db.consultarMatricula(matr);

            if(res == null){
                Toast.makeText(getApplicationContext(), "No hi ha nom", Toast.LENGTH_SHORT).show();
                System.out.println("no hi ha nom");
                return;
            }

            if(!res.equals("")){
                Toast.makeText(getApplicationContext(), res, Toast.LENGTH_SHORT).show();
                System.out.println("correcte");
            } else{
                Toast.makeText(getApplicationContext(), "Matrícula no trobada", Toast.LENGTH_SHORT).show();
                System.out.println("error");
            }
        }

    }

}
